﻿namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new("Pesho", "Peshow", 25);

            Console.WriteLine(person);
        }
    }
}