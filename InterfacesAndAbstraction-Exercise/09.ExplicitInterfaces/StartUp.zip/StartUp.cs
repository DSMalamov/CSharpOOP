﻿
using _09.ExplicitInterfaces.Core;
using _09.ExplicitInterfaces.Core.Interface;

IEngine engine = new Engine();
engine.Run();
